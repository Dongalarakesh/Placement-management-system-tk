//repository class

package  com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

//extend JpaRepository
public interface UserRepository extends JpaRepository<User, Integer>{

	
}
