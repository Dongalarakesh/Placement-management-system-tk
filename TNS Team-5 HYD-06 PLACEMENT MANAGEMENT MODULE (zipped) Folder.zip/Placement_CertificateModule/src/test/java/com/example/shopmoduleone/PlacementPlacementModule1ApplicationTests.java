package com.example.shopmoduleone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementPlacementModule1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
