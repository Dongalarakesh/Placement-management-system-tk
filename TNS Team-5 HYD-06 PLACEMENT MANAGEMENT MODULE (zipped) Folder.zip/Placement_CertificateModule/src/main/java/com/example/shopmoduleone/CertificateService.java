package com.example.shopmoduleone;

import java.util.List;


//import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
@Service
//@Transactional
public class CertificateService {

	//object or repository
		@Autowired
		private CertificateRepository repo;
		
		//retrieve all the data
		public List<Certificate> listall(){
			
			return repo.findAll();
			
		}
		
		//insert the data
		public void save(Certificate certificate) {
			repo.save(certificate);	
		}
		
		//Retrieve specific data
		public Certificate get(Integer id) {
			return repo.findById(id).get();
		}
		
		//delete
		public void delete(Integer id) {
			repo.deleteById(id);
		}	


}

